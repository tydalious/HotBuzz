/* 
 * File:   uart1.h
 * Author: td1486
 *
 * Created on January 14, 2014, 1:12 PM
 */

#ifndef UART1_H
#define	UART1_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* UART1_H */

